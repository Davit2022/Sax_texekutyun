#include <iostream>

#ifdef ClassRoomAbstract
#define ClassroomAbstract.h
#endif



namespace classroomSingle{
    class ClassRoomSingle :public cra::ClassRoomAbstract {
    public:
        void print_detalis () {
         std::cout << "classroomsingle" << std::endl;
         }

         void registr_student() {
            std::cout << "aaaaaaaaa" << std::endl 
         }
        static ClassRoomSingle getInstance(){

        if (instace == null) {
            instace ==


        }
    };
}
