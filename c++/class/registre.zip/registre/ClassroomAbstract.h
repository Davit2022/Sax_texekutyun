class ClassRoomAbstract{
    public:
        virtual void register_student() = 0;
        virtual void print_detalis() = 0;
};
